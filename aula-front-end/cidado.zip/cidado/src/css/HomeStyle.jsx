import styled from "styled-components";

export const HomeStyle = styled.section`
    .container{
        background: #ddd;
        margin: 2rem 4rem;
        display: grid;
        grid-template-columns: repeat(11,1fr);
        gap: 2rem;

    }
    .container > .item{
        font-size: 30px;
        padding: 1em;
        color: blue;
    }
    .container > .item1{
        background-color: red;
        grid-row: 4/5 ; //mexe na posicao da altura;
        grid-column: 3/4;  //mexe na posicao lateral;
    }
    .container > .item2{
        background: yellow;
        grid-column: 1/-1 ; //vai ate o final e volta negativo
    }
    .container > .item3{
        background: purple;
        grid-column: 1/4;
    
    }
`
const Header =()=>{
    return(
        <>
        <div className='header'>
            <h1>Calculadora IMC</h1>
        </div>
        </>
    )
}
export default Header
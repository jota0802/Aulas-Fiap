
import { Outlet } from "react-router-dom"
import Loja from "./components/Loja"

function App() {

  return (
    <>
      <Outlet/>
      <Loja/>
    </>
  )
}

export default App

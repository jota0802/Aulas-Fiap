import styled from "styled-components";

export const LojaStyle = styled.section`
    header{
        background: #ddd;
        padding: 1rem;
        text-align: center;
    }
    main{
        display: grid;
        grid-template-columns: repeat(1,1fr);
        gap: 1rem;
        padding: 1rem;
    }
    .produto{
        border: 1px solid #ddd;
        padding: 1rem;
        text-align: center;
    }
    .produto img{
    }
    .produto h2{
        font-size: 1.5rem;
    }
    .produto p{
        font-size: 1rem;
    }


`
function HelloWord(){

    //declarando as variaveis

    let nome = "cidade"

    const clique=() =>{alert(`ola dev, ${nome}`)}
    return(
        <>
        <p>helloword</p>
        <p>salve: {nome}</p>
        <button onClick={clique}> clique</button>
        </>
    )
}
export default HelloWord
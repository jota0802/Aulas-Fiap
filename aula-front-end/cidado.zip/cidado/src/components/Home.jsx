import { HomeStyle } from '../css/HomeStyle';

const Home =()=> {
    return (
        <HomeStyle>

            <div className="container">
                <div className="item item1">EGGxample1</div>
                <div className="item item2">EGGxample1</div>
                <div className="item item3">EGGxample1</div>
                <div className="item item4">EGGxample1</div>
                <div className="item item5">EGGxample1</div>
                <div className="item item6">EGGxample1</div>
            </div>

           
        </HomeStyle>

        )

}

export default Home;
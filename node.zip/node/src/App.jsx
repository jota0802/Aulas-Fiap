import { useEffect, useState } from "react"


//importando Componentes
import Header from "./components/Header"
import Resultado from "./components/Resultado"

function App() {

  //Hooks - useState - manipula o estado da vavriavel
  const[altura,setAltura]=useState(0)
  const[peso,setPeso]=useState(0)
  const[resultado,setResultado]=useState(0)
  const[mostrarresultado,setMostrarResultado]=useState(false)

  //criando a função calcular IMC

  const calcularImc=()=>{
    const int = peso / (altura**2)
    return setResultado(imc.toFixed(2))
  }

  //Hooks -useEffects - vai executar uma ação - chamar o componente resultado

  useEffect(()=>{
    //criando uma condicional ternaria 
    resultado > 0 ? setMostrarResultado(true): setMostrarResultado(false)
  },[resultado])

  return (
    <>
    <div className="container">
      <div className="box">
            {/*Chamando o componente Header */}
            <Header/>
            <form>
              <div>
                <label htmlFor="altura">Altura<span className='span'>(Ex. 1,80)</span></label>
                <input type="number" id="altura" placeholder="Altura" 
                onBlur={({ target})=>parseInt(setAltura(target.value))}/>
              </div>

              <div>
                <label htmlFor="peso">Peso<span className='span'>(Ex.80)</span></label>
                <input type="number" id="peso" placeholder="peso" 
                onBlur={({ target})=>parseInt(setPeso(target.value))}/>
              </div>

              <button type="submit" onClick={calcularImc}>Calcular</button>
            </form>

          {/*trazendo os dados de resultado desestruração */}
          <Resultado/>
          {mostrarresultado &&(
            <Resultado resultado={resultado}/>
          )}
          
      </div>
    </div>
    </>
  )
}

export default App

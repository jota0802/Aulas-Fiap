import imagem from "./assets/imagem.jfif"
import HelloWord from './components/HelloWord.jsx'
function App() {
  
  //declarando variaveis

  let nome = "É O CELSO!";
  let sobreNome = "ROSSUMOANNO";
  let novoNome = nome.toUpperCase();

  ///criando função:

  function soma(a,b){
    return a + b;

  }
  
  //criando arrow function

  const soma1=(c,d) => {return c+d}

  return (
    //fragments
    <>
      <h2>{novoNome}</h2>
      <h2>{sobreNome}</h2>
      <p>soma: {soma(20,8)}</p>
      <p>soma arrow: {soma1(70,5)}</p>
      <img src={imagem} alt="imagem" width={600} height={250}/>

      <HelloWord/>
      
    </>
  )
}

export default App

import { LojaStyle } from '../css/LojaStyle';
 
const Loja =()=>{
    return(

    <LojaStyle>
        <header>
            <h1>Loja de Produtos</h1>
        </header>
        <main>
            <article className='produto-grid'>
                <section className='produto'>
                    <img src='https://via.placeholder.com/150' alt='produto' />
                    <h2>Produto 1</h2>
                    <p>Descrição do produto 1</p>
                    <p>R$ 100,00</p>
                </section>
                <section className='produto'>
                    <img src='https://via.placeholder.com/150' alt='produto' />
                    <h2>Produto 2</h2>
                    <p>Descrição do produto 2</p>
                    <p>R$ 200,00</p>
                </section>
                <section className='produto'>
                    <img src='https://via.placeholder.com/150' alt='produto' />
                    <h2>Produto 3</h2>
                    <p>Descrição do produto 3</p>
                    <p>R$ 300,00</p>
                </section>
            </article>
        </main>
    </LojaStyle>

    )
}

export default Loja;
const Dados =(resultado)=>{
    if(resultado < 18.5){
        return(
            <>
                <td>Abaixo do Peso</td>
                <td>Abaixo de 18,5</td>
            </>
        )
    }
    else if(18.5 < resultado < 25){
        return(
            <>
                <td>Peso Normal</td>
                <td>Entre 18.5 - 25</td>
            </>
        )
    }
    else if(25 <resultado < 34){
        return(
            <>
                <td>Sobre Peso</td>
                <td>Entre 25 - 30</td>
            </>
        )
    }
    else if(35 < resultado < 40){
        return(
            <>
                <td>Pesado</td>
                <td>entre 35 - 40</td>
            </>
        )
    }
    else {
        return(
            <>
                <td>Pesadão</td>
                <td>Acima de 50</td>
            </>
        )
    }
}

const Resultado =({resultado})=>{
    return(
        <>
        <div className="resultado">
            <h2>Seu IMC é de:</h2>
            <span className="imcSpan">{resultado}</span>
            <table className="tabela">
                <thead className="tableHeader">
                    <tr>
                        <th>Classificação</th>
                        <th>IMC</th>
                    </tr>
                </thead>
                <tbody className="tableBody">
                    <tr>
                    {Dados(resultado)}
                    </tr>
                </tbody>
            </table>
        </div>
        </>
    )
}
export default Resultado